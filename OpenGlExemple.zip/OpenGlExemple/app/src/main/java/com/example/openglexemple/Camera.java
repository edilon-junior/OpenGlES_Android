package com.example.openglexemple;

public class Camera {

    private float[] position;

    public Camera(){
        position = new float[]{0f,0f,0f};
    }

    public float[] getPosition(){
        return this.position;
    }
}
