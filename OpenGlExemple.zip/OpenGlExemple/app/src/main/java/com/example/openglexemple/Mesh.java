package com.example.openglexemple;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Mesh {
    float[] vertices;
    float[] textures;
    float[] normals;
    float[] colors;
    int[] indices;

    private FloatBuffer mPositions;
    private FloatBuffer mColors;
    private FloatBuffer mNormals;
    private FloatBuffer mTextureCoordinates;
    private final int mBytesPerFloat = 4;

    private Material material;

    public Mesh(float[] vertices, float[] textures, float[] normals) {
        this.vertices = vertices;
        this.textures = textures;
        this.normals = normals;
        this.colors = new float[0];
    }

    public Mesh(float[] vertices, float[] textures, float[] normals, int[] indices) {
        this.vertices = vertices;
        this.textures = textures;
        this.normals = normals;
        this.colors = new float[0];
        this.indices = indices;
    }

    public void setColors(float[] colors) {
        this.colors = colors;
    }

    public float[] getVertices() {
        return this.vertices;
    }

    public float[] getTextures() {
        return this.textures;
    }

    public float[] getNormals() {
        return this.normals;
    }

    public float[] getColors() {
        return this.colors;
    }

    public int[] getIndices() {
        return this.indices;
    }

    public FloatBuffer getBufferPositions() {
        return this.mPositions;
    }

    public FloatBuffer getBufferNormals() {
        return this.mNormals;
    }

    public FloatBuffer getBufferTextureCoordinates() {
        return this.mTextureCoordinates;
    }

    public FloatBuffer getBufferColors() {
        return this.mColors;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Material getMaterial() {
        return this.material;
    }

    public void initializeBuffers() {
        // Initialize the buffers.
        mPositions = ByteBuffer.allocateDirect(vertices.length * mBytesPerFloat)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        mPositions.put(vertices).position(0);

        //for PLY file format
        if (colors.length > 0) {
            mColors = ByteBuffer.allocateDirect(colors.length * mBytesPerFloat)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            mColors.put(colors).position(0);
        }
        if (normals.length > 0) {
            mNormals = ByteBuffer.allocateDirect(normals.length * mBytesPerFloat)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            mNormals.put(normals).position(0);
        }
        if (textures.length > 0) {
            mTextureCoordinates = ByteBuffer.allocateDirect(textures.length * mBytesPerFloat)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            mTextureCoordinates.put(textures).position(0);
        }
    }

}
