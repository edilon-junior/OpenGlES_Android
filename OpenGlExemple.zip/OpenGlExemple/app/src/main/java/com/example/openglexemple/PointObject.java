package com.example.openglexemple;

import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class PointObject {

    private final int BYTES_PER_FLOAT = 4;

    private final float[] modelMatrix = new float[16];
    private final float[] modelPosition =  new float[] {0.0f, 0.0f, 0.0f, 1.0f};
    private final float[] color;
    private float[] textures;
    private float[] size;

    private Vector3f position;

    private Vector3f rotation_axis;

    private FloatBuffer bufferPosition;
    private FloatBuffer bufferColor;
    private FloatBuffer  bufferTextureCoordinates;

    private float rotation_angle;


    public PointObject(Vector3f position, float[] color, float[] size){
        Matrix.setIdentityM(modelMatrix, 0);
        this.position = position;
        this.color = color;
        this.textures = new float[0];
        this.size = size;
        this.rotation_angle = 0.0f;
        this.rotation_axis = new Vector3f(1,0,0);

        initializeBuffers();
    }

    public void initializeBuffers() {
        // Initialize the buffers.
        bufferPosition = ByteBuffer.allocateDirect(modelPosition.length * BYTES_PER_FLOAT)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        bufferPosition.put(modelPosition).position(0);

        if (color.length > 0) {
            bufferColor = ByteBuffer.allocateDirect(color.length * BYTES_PER_FLOAT)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            bufferColor.put(color).position(0);
        }

        if (textures.length > 0) {
            bufferTextureCoordinates = ByteBuffer.allocateDirect(textures.length * BYTES_PER_FLOAT)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            bufferTextureCoordinates.put(textures).position(0);
        }
    }

    public float[] getModelMatrix(){
        return this.modelMatrix;
    }

    public float[] getModelPosition(){
        return this.modelPosition;
    }

    public void setPosition(float x, float y, float z){
        this.position.set(x,y,z);
    }

    public float[] getPosition() {
        return this.position.toFloat();
    }


    public float[] getColor(){
        return this.color;
    }

    public FloatBuffer getBufferPosition(){
        return this.bufferPosition;
    }

    public FloatBuffer getBufferColor(){
        return this.bufferColor;
    }

    public float[] getSize(){
        return this.size;
    }

    public void setRotation(float angleInDegrees, float x, float y, float z){
        this.rotation_angle = angleInDegrees;
        this.rotation_axis.set(x,y,z);
    }

    public void translate(float x, float y, float z){
        this.position.keepAdd(x,y,z);
    }

    public void update(){
        Matrix.translateM(modelMatrix, 0,position.x,position.y,position.z);
        Matrix.rotateM(modelMatrix, 0, rotation_angle, rotation_axis.x, rotation_axis.y, rotation_axis.z);
    }

    public void cleanUp(){
        Matrix.setIdentityM(modelMatrix, 0);
    }

}
