package com.example.openglexemple;

import java.util.ArrayList;
import java.util.List;

public class Scene {

    private List<GameObject> gameObjectList = new ArrayList<GameObject>();

    public Scene(){

    }
}
