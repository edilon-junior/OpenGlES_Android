package com.example.openglexemple;

public class Utils {

    public static void printMatrix(float[] mat){
        String result = "";
        result = result + mat[0]+" "+mat[4]+" "+mat[8]+" "+mat[12]+"\n";
        result = result + mat[1]+" "+mat[5]+" "+mat[9]+" "+mat[13]+"\n";
        result = result + mat[2]+" "+mat[6]+" "+mat[10]+" "+mat[14]+"\n";
        result = result + mat[3]+" "+mat[7]+" "+mat[11]+" "+mat[15]+"\n";
        System.out.print(result);
    }
    public static void printFloatArray(float[] floatArray){
        String result = "";
        for(float i:floatArray){
            result = result +i+" ";
        }
        result = result + "\n";
        System.out.print(result);
    }
}
