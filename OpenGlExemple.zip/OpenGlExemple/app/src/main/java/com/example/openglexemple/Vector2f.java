package com.example.openglexemple;

public class Vector2f {
    public float x;
    public float y;

    private Vector2f proj;

    public Vector2f() {
        this.x = 0;
        this.y = 0;
    }

    public Vector2f(Vector2f v) {
        this.x = v.x;
        this.y = v.y;
    }

    public Vector2f(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void set(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void set(Vector2f v) {
        this.x = v.x;
        this.y = v.y;
    }

    public Vector2f clone() {
        return new Vector2f(this);
    }

    public void keepAdd(Vector2f v) {
        this.x += v.x;
        this.y += v.y;
    }

    public Vector2f add(Vector2f v) {
        Vector2f vec = clone();
        vec.keepAdd(v);
        return vec;
    }

    public void keepSub(Vector2f v) {
        this.x -= v.x;
        this.y -= v.y;
    }

    public Vector2f sub(Vector2f v) {
        Vector2f vec = clone();
        vec.keepSub(v);
        return vec;
    }

    public void keepTimes(float k) {
        this.x *= k;
        this.y *= k;
    }

    public Vector2f times(float k) {
        Vector2f vec = clone();
        vec.keepTimes(k);
        return vec;
    }

    public float dot(Vector2f v) {
        return this.x * v.x + this.y * v.y;
    }

    public Vector3f cross(Vector2f v) {
        float x = this.y * 0 - 0 * v.y;
        float y = 0 * v.x - this.x * 0;
        float z = this.x * v.y - this.y * v.x;
        return new Vector3f(x, y, z);
    }

    public float length() {
        return (float) Math.sqrt(this.dot(this));
    }

    public Vector2f proj(Vector2f v) {
        Vector2f proj = v.times(this.dot(v) / v.dot(v));
        this.setProj(proj);
        return proj;
    }

    public Vector2f ortoProj(Vector2f v) {
        if (this.proj != null) {
            return this.sub(proj);
        }
        final Vector2f sub = this.sub(this.proj(v));
        return sub;
    }

    private void setProj(Vector2f proj) {
        this.proj = proj;
    }

    private float[] toFloat(){
        return new float[]{this.x, this.y};
    }
}
