package com.example.openglexemple;

import androidx.annotation.NonNull;

public class Vector3f {
    public float x;
    public float y;
    public float z;
    private Vector3f proj;
    private Vector3f v;

    public Vector3f(){
        this.x = 0;
        this.y = 0;
        this.z = 0;
    }

    public Vector3f(Vector3f v){
        this.x = v.x;
        this.y = v.y;
        this.z = v.z;
    }

    public Vector3f(float x, float y, float z ){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void set(float x, float y, float z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void set(float[] vec){
        this.x = vec[0];
        this.y = vec[1];
        this.z = vec[2];
    }

    public void set(Vector3f v){
        this.x = v.x;
        this.y = v.y;
        this.z = v.z;
    }

    public Vector3f clone(){
        Vector3f result = new Vector3f(this);
        return result;
    }

    /**
     *
     * @return unit vector of this
     */
    public Vector3f normalized(){
        Vector3f result = clone().times(this.length());
        return result;
    }

    public void keepAdd(Vector3f v){
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
    }

    public void keepAdd(float x, float y, float z){
        this.x += x;
        this.y += y;
        this.z += z;
    }

    public Vector3f add(Vector3f v){
        Vector3f vec = clone();
        vec.keepAdd(v);
        return vec;
    }

    public void keepSub(Vector3f v){
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
    }

    public Vector3f sub(Vector3f v){
        Vector3f vec = clone();
        vec.keepSub(v);
        return vec;
    }

    public void keepTimes(float k){
        this.x *= k;
        this.y *= k;
        this.z *= k;
    }

    public Vector3f times(float k){
        Vector3f vec = clone();
        vec.keepTimes(k);
        return vec;
    }

    public float dot(@NonNull Vector3f v){
        this.v = v;
        return this.x*v.x + this.y*v.y + this.z*v.z;
    }

    public Vector3f cross(Vector3f v){
        float x = this.y*v.z - this.z*v.y;
        float y = this.z*v.x - this.x*v.z;
        float z = this.x*v.y - this.y*v.x;
        return new Vector3f(x,y,z);
    }

    public float length(){
        return (float) Math.sqrt(this.dot(this));
    }

    public Vector3f proj(Vector3f v){
        Vector3f proj = v.times(this.dot(v)/v.dot(v));
        this.setProj(proj);
        return proj;
    }

    public Vector3f ortoProj(Vector3f v){
        if(this.proj != null){
            return this.sub(proj);
        }
        final Vector3f sub = this.sub(this.proj(v));
        return sub;
    }

    private void setProj(Vector3f proj){
        this.proj = proj;
    }

    public float[] toFloat(){
        return new float[]{this.x, this.y, this.z};
    }

    public String toString(){
        return new String("("+x+", "+y+", "+z+")");
    }
}
